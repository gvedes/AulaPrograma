from django.forms import ModelForm
from django.core.exceptions import ValidationError
from .models import Saidas

class SaidaForm(ModelForm):
    class Meta:
        model = Saidas
        fields = ['produto', 'quantidade', 'preco']
    
    def clean(self):
        cleaned_data = super().clean()
        produto = cleaned_data.get('produto')
        quantidade = cleaned_data.get('quantidade')
        
        if produto and quantidade:
            if quantidade > produto.quantidade:
                raise ValidationError(
                    f'Quantidade insuficiente em estoque. Disponível: {produto.quantidade}'
                )
        
        return cleaned_data